v1.11, build 33 (16.07.2018)
---------------------------------
+ Included to AIMP v4.60 bundle as default plugin


v1.11, build 32 (11.05.2018)
---------------------------------
* 3rd party libraries have been updated
* The German, Czech and Slovak localizations have been added
- Small isses were fixed


v1.11, build 31 (19.11.2017)
---------------------------------
+ Support for feed arts


v1.10, build 29 (12.11.2017)
---------------------------------
- Fixed: some feeds parses incorrectly


v1.10, build 27 (08.08.2017)
---------------------------------
+ High DPI support
+ Support for AIMP v4.50
* An ability to delete invalid links to local copies


v1.00, build 24 (13.04.2017)
---------------------------------
- Fixed: settings dialog - macros legend does not work


v1.00, build 23 (03.01.2017)
---------------------------------
- Fixed: feeds that does not provide ids for the episodes cannot be displayed by plugin


v1.00, build 22 (26.11.2016)
---------------------------------
* Compatibility with v4.12 beta has been improved


v1.00, build 21 (23.11.2016)
---------------------------------
- Small bugs were fixed


v1.00, build 20 (01.11.2016)
---------------------------------
- Fixed: downloader detects file format incorrectly in some cases


v1.00, build 19 (26.09.2016)
---------------------------------
- Fixed: date parser crashes in some cases


v1.00 RC, build 18 (25.10.2016)
---------------------------------
+ Added: Belarusian (official) localization
- Fixed: the "Automatically download new episodes" option does not work in some cases


v1.00 RC, build 16 (14.09.2016)
---------------------------------
- Fixed: date parses incorrectly with negative time zone offset
- Fixed: podcast feeds with the application/octen-stream content type cannot be downloaded


v1.00 Beta, build 14 (27.08.2016)
---------------------------------
+ Added: Bulgarian localization
- Fixed: the EpisodePublishDate macro returns unreadable value in some cases


v1.00 Beta, build 13 (22.08.2016)
---------------------------------
+ Added: commands to context menu of playlist
+ Added: Ukranian localization
* Replace the "location of local copy" command by the "file location" built-in command
- Fix: modal windows of plugin appears behind the main window if the "stay on top" option is switched on


v0.50 Beta Build 11 (12.08.2016)
---------------------------------
- Fixed: encoding detects incorrectly for some feeds


v0.50 Beta, build 10 (29.07.2016)
---------------------------------
+ Added: support of iTunes feeds


v0.50 Beta, build 9 (28.07.2016)
---------------------------------
+ Added: Eesti and Espanol-AR localizations
- Fixed: subscription cannot be edited
- Fixed: podcast feed cannot be downloaded if it contains the ":" symbol after the host name